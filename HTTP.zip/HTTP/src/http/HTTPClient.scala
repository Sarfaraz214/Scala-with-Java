package http

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

object HTTPClient {
  
  def main(args: Array[String])
  {
    try
    {
      getData()
    } catch {
      case t: Throwable => t.printStackTrace()
    }
  }
  
  def getData() = {
    val url: String = "http://data.fixer.io/api/latest?access_key=515bcf7b7efec53663944167f7c2bf54"
    val obj: URL = new URL(url)
    var con: HttpURLConnection = obj.openConnection().asInstanceOf[HttpURLConnection]
    con.setRequestMethod("GET")
    val responseCode: Int = con.getResponseCode
    println("Sending 'GET' request to URL : " + url)
    println("Response Code : " + responseCode)
    val br: BufferedReader = new BufferedReader(
          new InputStreamReader(con.getInputStream))
    var inputLine: String = "";
    var response: StringBuilder = new StringBuilder
    
    /*while( {inputLine = br.readLine(); inputLine != null} ) //In this case (inputLine = br.readLine()) is a functional literal that returns type Unit
	  {
      response.append(inputLine)
	  }*/
    
    Stream.continually(br.readLine()).takeWhile(_ != null) foreach { line =>
      response.append(line)
    }
	  br.close()
	  
    //println(response.toString())
	  
	  val myResponse: JSONObject = new JSONObject(response.toString())
	  println("Base: " + myResponse.getString("base"))
	  println("Timestamp: " + myResponse.getLong("timestamp"))
	  
	  val ratesResponse: JSONObject = new JSONObject(myResponse.getJSONObject("rates").toString())
	  println("INR- "+ ratesResponse.getDouble("INR"))
	  println("USD- "+ ratesResponse.getDouble("USD"))
  }
}